# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '1652482339d24ca3f4fd70ddfa76cddcfcade3781b69d82ebbb20de98748a811d0385fa1b49a358efe8fc3c253fd078fe5500f2f8f5785d7eb7b3dbdf5e28392'